See http://jakarta.apache.org/commons/launcher/ for additional and 
up-to-date information on Commons Launcher.
